How to import Nanybot's library is as follows:

<< from Nanybot.client import Nanybot >>

An example:

from Nanybot.client import Nanybot

bot = Nanybot("Your Auth Account")


Made by Team Nanymous

Address of our team's GitHub :

https://github.com/Nanymous/Rubi.git